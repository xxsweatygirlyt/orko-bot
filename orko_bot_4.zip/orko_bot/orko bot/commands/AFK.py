from discord.ext import commands

class AFK(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def afk(self, ctx, reason=None):
        """Set an AFK status with an optional reason."""
        # Your AFK logic here
        # Example: Send a message indicating that the user is AFK
        if reason:
            await ctx.send(f"{ctx.author.mention} is now AFK: {reason}")
        else:
            await ctx.send(f"{ctx.author.mention} is now AFK")

def setup(bot):
    bot.add_cog(AFK(bot))

def teardown(bot):
    bot.remove_cog("AFK")

def setup(bot):
    bot.add_cog(AFK(bot))

def teardown(bot):
    bot.remove_cog("AFK")

def setup(bot):
    bot.add_cog(AFK(bot))

def teardown(bot):
    bot.remove_cog("AFK")
