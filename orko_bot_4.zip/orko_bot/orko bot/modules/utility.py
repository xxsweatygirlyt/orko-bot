import discord
from discord.ext import commands

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        """Check the bot's latency."""
        latency = round(self.bot.latency * 1000)
        await ctx.send(f'Pong! Latency: {latency}ms')

    @commands.command()
    async def serverinfo(self, ctx):
        """Display information about the server."""
        server = ctx.guild
        member_count = server.member_count
        online_count = sum(member.status != discord.Status.offline for member in server.members)
        text_channels = len(server.text_channels)
        voice_channels = len(server.voice_channels)
        server_owner = server.owner.name

        embed = discord.Embed(title='Server Information', color=discord.Color.green())
        embed.set_thumbnail(url=server.icon_url)
        embed.add_field(name='Server Name', value=server.name, inline=False)
        embed.add_field(name='Member Count', value=member_count, inline=False)
        embed.add_field(name='Online Members', value=online_count, inline=False)
        embed.add_field(name='Text Channels', value=text_channels, inline=False)
        embed.add_field(name='Voice Channels', value=voice_channels, inline=False)
        embed.add_field(name='Server Owner', value=server_owner, inline=False)

        await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(Utility(bot))
