import discord
from discord.ext import commands

class CommandHandler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user:
            return

        ctx = await self.bot.get_context(message)

        if ctx.valid:
            await self.bot.invoke(ctx)

def setup(bot):
    bot.add_cog(CommandHandler(bot))
