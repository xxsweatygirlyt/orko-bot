import discord
from discord.ext import commands

class OnMemberJoin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        # Your code for handling the member join event
        pass

def setup(bot):
    bot.add_cog(OnMemberJoin(bot))
