import discord
from discord.ext import commands

class OnReady(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print(f'Logged in as {self.bot.user.name} ({self.bot.user.id})')
        print('------')

        # Set the bot's activity and status
        activity = discord.Activity(type=discord.ActivityType.playing, name='with commands')
        await self.bot.change_presence(activity=activity, status=discord.Status.online)

def setup(bot):
    bot.add_cog(OnReady(bot))
