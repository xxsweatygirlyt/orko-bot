import discord
from discord.ext import commands

class OnMemberLeave(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        # Your code for handling the member leave event
        pass

def setup(bot):
    bot.add_cog(OnMemberLeave(bot))
