import discord
from discord.ext import commands

class OnMessageDelete(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.sniped_messages = {}

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        # Store the deleted message in the dictionary
        self.sniped_messages[message.channel.id] = message

def setup(bot):
    bot.add_cog(OnMessageDelete(bot))
