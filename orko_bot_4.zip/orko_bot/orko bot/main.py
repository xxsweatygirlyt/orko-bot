import discord
from discord.ext import commands, tasks

intents = discord.Intents.default()
intents.message_content = True  # Enable privileged message content intent
intents.members = True
bot = commands.Bot(command_prefix='#',  help_command=None, intents=intents)


@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} ({bot.user.id})')


@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    await bot.process_commands(message)

@bot.command()
@commands.has_permissions(administrator=True)
async def mute(ctx, member: discord.Member):
    guild = ctx.guild
    muted_role = await get_muted_role(guild)  # Make sure to await the coroutine
    if muted_role is None:
        await ctx.send("Muted role not found.")
        return
    await member.add_roles(muted_role)
    await ctx.send(f"{member} has been muted.")

async def get_muted_role(guild):
    muted_role = discord.utils.get(guild.roles, name="Muted")
if not muted_role:
        muted_role = await guild.create_role(name='Muted')
        for channel in guild.channels:
            await channel.set_permissions(muted_role, send_messages=False)
    return muted_role

@bot.command()
@commands.has_permissions(administrator=True)
async def ban(ctx, member: discord.Member):
    """Timeout a member for a specified duration in minutes"""
    if member in timeouts:
        await ctx.send(f"{member} is already timed out.")
        return

    timeout_end = datetime.now() + timedelta(minutes=duration)
    timeouts[member] = timeout_end

    await member.add_roles(get_muted_role(ctx.guild))
    await ctx.send(f"{member} has been timed out for {duration} minutes.")
@tasks.loop(minutes=1)
async def check_timeouts():
    """Check if timeouts have expired"""
    for member, timeout_end in timeouts.copy().items():
        if datetime.now() >= timeout_end:
            del timeouts[member]
            await member.remove_roles(get_muted_role(member.guild))


@bot.command()
@commands.has_permissions(administrator=True)
async def lockdown(ctx):
    # Check if the channel is already in lockdown
    if ctx.channel.overwrites_for(ctx.guild.default_role).send_messages is False:
        await ctx.send("The channel is already in lockdown.")
        return
    
    # Set the channel permissions to disallow sending messages for @everyone
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
    await ctx.send("The channel has been locked down.")

@lockdown.error
async def lockdown_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("You do not have permission to use this command.")


@bot.command()
async def snipe(ctx):
    # Check if there is a deleted message to snipe
    if ctx.channel.id in sniped_messages:
#      deleted_message = sniped_messages[ctx.channel.id]
        author = deleted_message.author
        content = deleted_message.content

        # Send the sniped message information
        await ctx.send(f"Sniped message from {author.name}: {content}")
    else:
        await ctx.send("No recently deleted messages to snipe.")


@bot.command()
async def unmute(ctx, member: discord.Member):
    muted_role = discord.utils.get(ctx.guild.roles, name="Muted")

    if muted_role in member.roles:
        await member.remove_roles(muted_role)
        await ctx.send(f"{member.mention} has been unmuted.")
    else:
        await ctx.send(f"{member.mention} is not muted.")


@bot.command()
async def untimeout(ctx, member: discord.Member):
    if member in timeouts:
        # Remove the member from the timeouts dictionary
        del timeouts[member]
        await ctx.send(f'{member.mention} has been untimed out.')
    else:
        await ctx.send(f'{member.mention} is not currently timed out.')


@bot.command()
async def avatar(ctx, member: discord.Member = None):
    if member is None:
        member = ctx.author

    embed = discord.Embed(title=f"Avatar for {member.name}", color=discord.Color.blurple())
    embed.set_image(url=member.avatar_url)

    await ctx.send(embed=embed)


@bot.command()
async def help(ctx):
    embed = discord.Embed(title='Help Menu', description='List of available commands:', color=discord.Color.blue())

    for command in bot.commands:
        embed.add_field(name=command.name, value=command.help, inline=False)

    await ctx.send(embed=embed)

# Load events from the events folder
bot.load_extension('events.on_ready')
bot.load_extension('events.on_message')
bot.load_extension('events.on_member_edit')
bot.load_extension('events.on_message_delete')
bot.load_extension('events.on_member_leave')
bot.load_extension('events.on_member_join')

# Load command handlers from the handlers folder
bot.load_extension('handlers.command_handler')
bot.load_extension('handlers.event_handler')

# Load modules from the modules folder
bot.load_extension('modules.mod')
bot.load_extension('modules.utility')

# Load commands from the commands folder
bot.load_extension('commands.ban')
bot.load_extension('commands.mute')
bot.load_extension('commands.timeout')
bot.load_extension('commands.AFK')
bot.load_extension('commands.avatar')
bot.load_extension('commands.lockdown')
bot.load_extension('commands.snipe')
bot.load_extension('commands.unban')
bot.load_extension('commands.unmute')
bot.load_extension('commands.untimeout')
bot.load_extension('commands.help')

# Run the bot
bot.run('MTEwODQzODMxNzkwNjgwNDk0Ng.G9eNmG._U-6lyYTUJTbSZROiPrJ53nGGHzc1d6RTm90eM')
